

var mapFunction1 = function() {

  //for(i=0;i<this.sex.length;i++){

   var key=this.sex;
   var values={count:1,wzrost: this.height,waga: this.weight}
   emit(key,values);
 
};
var reduceFunc=function(sex,values){

var wynik={count:0,wzrost:0,waga:0};

for(i=0;i<values.length;i++){
wynik.count+=values[i].count;
wynik.wzrost+=values[i].wzrost;
wynik.waga+=values[i].waga;
}
return wynik ;
};

var finalizeFunc=function(sex,value){
value.sredniaWaga=(value.waga/value.count);
value.sredniWzrost=(value.wzrost/value.count);
return value;
}

db.people.mapReduce(
mapFunction1,
reduceFunc,
{out:"map1",
finalize:finalizeFunc}
)
printjson(db.map1.find().toArray());
