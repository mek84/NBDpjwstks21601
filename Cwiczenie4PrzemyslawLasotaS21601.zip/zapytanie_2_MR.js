

var mapFunction1 = function() {

  for(i=0;i<this.credit.length;i++){
   var waluta=this.credit[i]; 
   var saldo=this.credit[i];

   emit(waluta.currency,saldo.balance);
}
 
};
var reduceFunc=function(waluta,balance){


saldo=0;
for(i=0;i<balance.length;i++){
saldo+=balance[i];

}
return saldo ;
};



db.people.mapReduce(
mapFunction1,
reduceFunc,
{out:"map2"}
)
printjson(db.map2.find().toArray());
