

var mapFunction1 = function() {



   var key=this.nationality;
   var values={count:1,wzrost: this.height,waga: this.weight,bmi:this.weight/(this.height*this.height) }
   emit(key,values);
 
};
var reduceFunc=function(nationality,values){


var wynik={count:0,wzrost:0,waga:0,bmi:0,CalyzakresBMI:[],minBMI:0,maxBMI:0};
var pierwsze= values[0].bmi
for(i=0;i<values.length;i++){
wynik.count+=values[i].count;
wynik.wzrost+=values[i].wzrost;
wynik.waga+=values[i].waga;
wynik.bmi+=values[i].bmi
wynik.CalyzakresBMI.push(values[i].bmi)
if (pierwsze>=values[i].bmi){wynik.minBMI=values[i].bmi}
if (pierwsze>=values[i].bmi){wynik.maxBMI=pierwsze}else{wynik.maxBMI=values[i].bmi}

}

return wynik ;
};

var finalizeFunc=function(nationality,value){
value.avgBMI=(value.bmi/value.count);
return value;
}

db.people.mapReduce(
mapFunction1,
reduceFunc,
{out:"map4",
finalize:finalizeFunc}
)
printjson(db.map4.find().toArray());
