

var mapFunction1 = function() {

   var zawod=this.job; 
 
   emit(zawod,1);

 
};
var reduceFunc=function(zawod,value){

return Array.sum(value) ;
};



db.people.mapReduce(
mapFunction1,
reduceFunc,
{out:"map3"}
)
printjson(db.map3.find().toArray());
