printjson(db.people.aggregate([ 


{$match:

{$and:[{"nationality":"Poland"},{"sex":"Female"}]}
},
{$unwind:"$credit"}

,{$group:{_id:{waluta:"$credit.currency",narodowosc:"$nationality",plec:"$sex"}
,SumaSalda:{$sum:{$toDecimal:"$credit.balance"}},
SrednieSaldo:{$avg:{$toDecimal:"$credit.balance"}}


}
},
{$sort:{"credit.currency":-1}}
]).toArray())