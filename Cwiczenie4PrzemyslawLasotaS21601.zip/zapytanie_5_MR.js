

var mapFunction1 = function() {

  for(i=0;i<this.credit.length;i++){
   var waluta=this.credit[i].currency; 
   var values={saldo:this.credit[i].balance, count:1};

   emit(waluta,values);
}
 
};
var reduceFunc=function(waluta,balance){

var wynik={saldo:0,count:0}
for(i=0;i<balance.length;i++){
wynik.saldo+=balance[i].saldo;
wynik.count+=balance[i].count;

}
return wynik ;
};

var finalizeFunc=function(key,value){
value.avgSALDO=(value.saldo/value.count);
return value;
}

db.people.mapReduce(
mapFunction1,
reduceFunc,
{out:"map5",
query:{$and: [{sex:"Female"},{nationality:"Poland"}]},
finalize:finalizeFunc}
)
printjson(db.map5.find().toArray());
