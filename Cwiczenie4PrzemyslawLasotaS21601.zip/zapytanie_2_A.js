printjson(db.people.aggregate([ 
{$unwind:"$credit"},
{$group:{_id:"$credit.currency",SumaSalda:{$sum:{$toDecimal:"$credit.balance"}}}},
{$sort:{"credit.currency":-1}}
]).toArray())