printjson(db.people.findOne())
